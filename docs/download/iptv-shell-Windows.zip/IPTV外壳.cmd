@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
rem 万一系统 TEMP 目录被锁或不可写，把解包/缓存目录改到程序自己旁边
if not exist "%~dp0temp" mkdir "%~dp0temp"
set "TEMP=%~dp0temp"
set "TMP=%~dp0temp"
start "" "%~dp0IPTV-Shell\IPTV-Shell.exe"
endlocal
